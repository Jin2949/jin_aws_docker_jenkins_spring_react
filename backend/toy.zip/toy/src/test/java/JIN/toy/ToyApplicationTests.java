package JIN.toy;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ToyApplicationTests {

	@Test
	void contextLoads() {
	}

}
